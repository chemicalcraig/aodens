/********************************************
 * Program to calculate atomic transition
 * densities using an AO expansion.
 *
 * CTC 7-31-2014
 *
 * For further information, see:
 * JPCB, 117, 2032, 2013
 * JPCC, 114, 20834, 2010
 * *******************************************/

#include "main.h"
#include <vector>
using namespace std;

int main(int argc, char **argv) {
  //open input file
  comfile.open(argv[1]);

  //parse input file
  char tempc[1000];
  string temps;

  /* 
   * Get calculation type
   * "transden" - get ao transition densities
   * "overlap"  - get overlap of two chromophore
   *              transition densities
   */
  
  comfile.getline(tempc,1000);
  temps = strtok(tempc, ":");
  temps = strtok(NULL, " :");
  
  if (temps == "transden") {
    /* get nwchem log file name */
    comfile.getline(tempc,1000);
    temps = strtok(tempc,":");
    temps = strtok(NULL," :");

    /* get stuff from log file */
    vector<Atom> atom;
    vector<Molecule> molecule(1);

    parseLog(temps,atom,molecule);

  } else if (temps == "overlap") {

  } else {
    cout<<"Unrecognized calculation type!"<<endl;
    return -1;
  }

  return 0;
}
