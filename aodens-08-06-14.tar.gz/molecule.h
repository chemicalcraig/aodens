#ifndef MOLECULE_H
#define MOLECULE_H

#include <vector>
#include "atom.h"
using namespace std;

class Molecule {
  public:
  int nao,nbasis;
  vector<int> nbasisatom;
  vector<string> nbasisatomorbital;
  vector<string> nbasisatomelement;
  double *posx,*posy,*posz;
  Atom *atoms;
  vector<Atom> atomsv;
  int natoms;
  int nx,ny,nz;
  double dx1,dx2,dx3,dy1,dy2,dy3,dz1,dz2,dz3;
  double ox,oy,oz;
  double ***dens, ***densrad;

  void setnatoms(int n) {natoms = n;};
  void setxyz(int x, int y, int z) {nx=x;ny=y;nz=z;};

  Molecule();
};

#endif // MOLECULE_H
