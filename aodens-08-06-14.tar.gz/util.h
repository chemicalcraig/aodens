#ifndef UTIL_H
#define UTIL_H
#include <cstring>
#include <vector>
#include <fstream>
#include <iostream>
#include "atom.h"
#include "molecule.h"
#include <iomanip>
using namespace std;

/* Search strings */
string geom_str=" Output coordinates";
string basislabel_str="    Basis function labels";

/* Skip several lines in input file */
void getnlines(ifstream &in, char *temp, int n, int length) {
  for (int i=0; i<n; i++) {
    in.getline(temp,length);
  }
}


/* Function to parse an NWChem output file */
/* Returns true if successful, false otherwise */

bool parseLog(string str, vector<Atom> &atomv, vector<Molecule> &molv) {
    
    ifstream infile;
    infile.open(str.c_str());
    cout<<"Opening file: "<<str.c_str()<<endl;

    char tempc[1000];
    int natoms=0;
    int nbasis=0;

    while(infile.getline(tempc, 1000)) {
      string temps(tempc);
/** Geometry **/     
      if (temps.compare(0,10,geom_str,0,10) == 0) {
        /* Skip a few lines to get to the geometry */
        getnlines(infile,tempc,3,1000);

        /* Read geometry */
        //get position in file
        int pos = infile.tellg();
        while (temps != "Atomic") {
          infile>>ws;
          infile.getline(tempc,1000);
          temps = strtok(tempc," ");
          //get natoms
          if (temps != "Atomic") {
            natoms++;
          }
        }
        /* Make an molecule entry and declare natoms for the molecule */
        molv[0].natoms = natoms;
        molv[0].atomsv.resize(natoms);

        //return to top of geometry
        infile.seekg(pos);
        infile.getline(tempc,1000);
        temps = strtok(tempc," ");
        int i=0;
        while(temps!= "Atomic") {
          //Assign atom numbers
          molv[0].atomsv[i].num = atoi(temps.c_str());
          temps = strtok(NULL," ");

          //Get atom type
          molv[0].atomsv[i].type = temps;

          //Get atom charge
          temps = strtok(NULL," ");
          molv[0].atomsv[i].charge = atof(temps.c_str());

          //X-coordinate
          temps = strtok(NULL," ");
          molv[0].atomsv[i].x = atof(temps.c_str());
          
          //Y-coordinate
          temps = strtok(NULL," ");
          molv[0].atomsv[i].y = atof(temps.c_str());

          //Z-coordinate
          temps = strtok(NULL," ");
          molv[0].atomsv[i].z = atof(temps.c_str());

          infile>>ws;
          infile.getline(tempc,1000);
          temps = strtok(tempc," ");
          i++;
        }
      } //end geometry
/** Basis Function Labels **/
      //infile.getline(tempc,1000);
      //temps = tempc;//
      //cout<<temps<<" "<<tempc<<endl;
      
      if (temps.compare(0,20,basislabel_str,0,20) == 0) {
        
        getnlines(infile,tempc,2,1000);

        int pos = infile.tellg();
        infile>>ws;
        infile.getline(tempc,1000);
        temps = tempc;
        while (temps != "DFT Final Molecular Orbital Analysis") {
          infile>>ws;
          infile.getline(tempc,1000);
          temps = tempc;
          
          //get nbasis
          if (temps != "DFT Final Molecular Orbital Analysis") {
            nbasis++;
          }
        }
          //return to top of geometry
          cout<<"nbasis = "<<nbasis<<endl;
          molv[0].nbasis = nbasis;
          molv[0].nbasisatom.resize(nbasis);
          molv[0].nbasisatomelement.resize(nbasis);
          molv[0].nbasisatomorbital.resize(nbasis);
          infile.seekg(pos);
          infile>>ws;
          infile.getline(tempc,1000);
          temps = tempc;
        while (temps != "DFT Final Molecular Orbital Analysis") {
          infile>>ws;
          infile.getline(tempc,1000);
          temps = tempc;
          

          cout<<tempc<<endl;
          if (temps != "DFT Final Molecular Orbital Analysis") {
            temps = strtok(tempc," ");
            //get function number
            int num = atoi(temps.c_str());
            temps = strtok(NULL," ");
            molv[0].nbasisatom[num-1] = atoi(temps.c_str());
            temps = strtok(NULL," ");
            molv[0].nbasisatomelement[num-1] = temps;
            temps = strtok(NULL," ");
            molv[0].nbasisatomorbital[num-1] = temps;
          }
        }
          //temps = strtok(tempc," ");
        
      } //end basis label
//cout<<temps<<endl;
    } //end reading
    //atom = new Atom[nbasis];
    //atom->num = 5;
    return true;
}

#endif // UTIL_H
