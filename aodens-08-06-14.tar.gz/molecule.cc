#include "molecule.h"

Molecule::Molecule()
{
}
